package com.example.ev2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class AsignacionEmpleadoDeptActivity extends AppCompatActivity {
    ArrayList<Empleado> listaEmpleados;
    ArrayList<Departamento> listaDepartamentos;
    Spinner spnEmpleados, spnDepartamentos;
    Button btnAsignar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asignacion_empleado_dept);

        spnEmpleados = findViewById(R.id.spnEmpleados);
        spnDepartamentos = findViewById(R.id.spnDepartamentos);
        btnAsignar = findViewById(R.id.btnAsignar);

        // Cargar empleados y departamentos en spinners (simulando que ya están creados)

        btnAsignar.setOnClickListener(v -> {
            int empleadoPos = spnEmpleados.getSelectedItemPosition();
            int deptPos = spnDepartamentos.getSelectedItemPosition();

            Empleado empleado = listaEmpleados.get(empleadoPos);
            Departamento departamento = listaDepartamentos.get(deptPos);

            empleado.setDepartamentoId(departamento.getId());
        });
    }
}
