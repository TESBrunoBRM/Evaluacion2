package com.example.ev2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Calendar;

public class RegistroEmpleadoActivity extends AppCompatActivity {
    ArrayList<Empleado> listaEmpleados = new ArrayList<>();
    EditText etNombre, etDireccion, etTelefono, etEmail, etFechaInicio, etSalario;
    Button btnGuardarEmpleado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_empleado);

        etNombre = findViewById(R.id.etNombre);
        etDireccion = findViewById(R.id.etDireccion);
        etTelefono = findViewById(R.id.etTelefono);
        etEmail = findViewById(R.id.etEmail);
        etFechaInicio = findViewById(R.id.etFechaInicio);
        etSalario = findViewById(R.id.etSalario);
        btnGuardarEmpleado = findViewById(R.id.btnGuardarEmpleado);

        etFechaInicio.setOnClickListener(v -> mostrarDatePicker());

        btnGuardarEmpleado.setOnClickListener(v -> {
            String id = "EMP" + (listaEmpleados.size() + 1); // ID generado automáticamente
            String nombre = etNombre.getText().toString();
            String direccion = etDireccion.getText().toString();
            String telefono = etTelefono.getText().toString();
            String email = etEmail.getText().toString();
            String fechaInicio = etFechaInicio.getText().toString();
            double salario = Double.parseDouble(etSalario.getText().toString());

            Empleado empleado = new Empleado(id, nombre, direccion, telefono, email, fechaInicio, salario);
            listaEmpleados.add(empleado);
        });
    }

    private void mostrarDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int anio = calendar.get(Calendar.YEAR);
        int mes = calendar.get(Calendar.MONTH);
        int dia = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, monthOfYear, dayOfMonth) -> {
            String fechaSeleccionada = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
            etFechaInicio.setText(fechaSeleccionada);
        }, anio, mes, dia);

        datePickerDialog.show();
    }
}
