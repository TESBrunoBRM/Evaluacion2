package com.example.ev2;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Calendar;

public class RegistroTiempoActivity extends AppCompatActivity {

    EditText etFecha, etHorasTrabajadas, etDescripcion;
    Spinner spnProyectos;
    Button btnRegistrarTiempo;
    ArrayList<Proyecto> listaProyectos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_tiempo);

        etFecha = findViewById(R.id.etFecha);
        etHorasTrabajadas = findViewById(R.id.etHorasTrabajadas);
        etDescripcion = findViewById(R.id.etDescripcion);
        spnProyectos = findViewById(R.id.spnProyectos);
        btnRegistrarTiempo = findViewById(R.id.btnRegistrarTiempo);

        listaProyectos.add(new Proyecto("PRJ1", "Proyecto Solar"));
        listaProyectos.add(new Proyecto("PRJ2", "Investigación de Energía Eólica"));

        // Cargar los nombres de los proyectos en el Spinner
        ArrayAdapter<String> adapterProyectos = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getProjectNames(listaProyectos));
        adapterProyectos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnProyectos.setAdapter(adapterProyectos);

        // Selector de fecha
        etFecha.setOnClickListener(v -> mostrarDatePicker());

        // Botón para registrar el tiempo
        btnRegistrarTiempo.setOnClickListener(v -> {
            String fecha = etFecha.getText().toString();
            String horas = etHorasTrabajadas.getText().toString();
            String descripcion = etDescripcion.getText().toString();
            String proyectoSeleccionado = spnProyectos.getSelectedItem().toString();

            if (!fecha.isEmpty() && !horas.isEmpty() && !descripcion.isEmpty()) {
                // Registro simulado del tiempo trabajado
                Toast.makeText(RegistroTiempoActivity.this, "Tiempo registrado para " + proyectoSeleccionado, Toast.LENGTH_SHORT).show();

                // Limpiar los campos
                etFecha.setText("");
                etHorasTrabajadas.setText("");
                etDescripcion.setText("");
                spnProyectos.setSelection(0);
            } else {
                Toast.makeText(RegistroTiempoActivity.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Método para obtener los nombres de los proyectos
    private ArrayList<String> getProjectNames(ArrayList<Proyecto> proyectos) {
        ArrayList<String> nombres = new ArrayList<>();
        for (Proyecto proyecto : proyectos) {
            nombres.add(proyecto.getNombre());
        }
        return nombres;
    }

    // Método para mostrar el selector de fecha
    private void mostrarDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int anio = calendar.get(Calendar.YEAR);
        int mes = calendar.get(Calendar.MONTH);
        int dia = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, monthOfYear, dayOfMonth) -> {
            String fechaSeleccionada = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
            etFecha.setText(fechaSeleccionada);
        }, anio, mes, dia);

        datePickerDialog.show();
    }
}
