package com.example.ev2;

public class Departamento {
    private String id;
    private String nombre;
    private String gerenteId;

    public Departamento(String id, String nombre, String gerenteId) {
        this.id = id;
        this.nombre = nombre;
        this.gerenteId = gerenteId;
    }

    // Getters y setters
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public void setGerenteId(String gerenteId) { this.gerenteId = gerenteId; }
    public String getGerenteId() { return gerenteId; }
}

