package com.example.ev2;

public class Proyecto {
    private String id;
    private String nombre;
    private String descripcion;
    private String fechaInicio;

    public Proyecto(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaInicio = fechaInicio;
    }

    // Getters y setters
    public String getId() { return id; }
    public String getNombre() { return nombre; }
}
