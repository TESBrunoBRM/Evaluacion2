package com.example.ev2;

public class RegistroTiempo {
    private String empleadoId;
    private String proyectoId;
    private String fecha;
    private int horasTrabajadas;
    private String descripcionTarea;

    public RegistroTiempo(String empleadoId, String proyectoId, String fecha, int horasTrabajadas, String descripcionTarea) {
        this.empleadoId = empleadoId;
        this.proyectoId = proyectoId;
        this.fecha = fecha;
        this.horasTrabajadas = horasTrabajadas;
        this.descripcionTarea = descripcionTarea;
    }

    // Getters y setters
    public String getEmpleadoId() { return empleadoId; }
    public String getProyectoId() { return proyectoId; }
}

