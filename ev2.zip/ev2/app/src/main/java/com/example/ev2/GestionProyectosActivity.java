package com.example.ev2;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Calendar;

public class GestionProyectosActivity extends AppCompatActivity {

    EditText etNombreProyecto, etDescripcionProyecto, etFechaInicio;
    Button btnAgregarProyecto, btnEliminarProyecto;
    ListView listViewProyectos;
    ArrayList<Proyecto> listaProyectos = new ArrayList<>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_proyectos);

        // Inicializar los elementos de la vista
        etNombreProyecto = findViewById(R.id.etNombreProyecto);
        etDescripcionProyecto = findViewById(R.id.etDescripcionProyecto);
        etFechaInicio = findViewById(R.id.etFechaInicio);
        btnAgregarProyecto = findViewById(R.id.btnAgregarProyecto);
        btnEliminarProyecto = findViewById(R.id.btnEliminarProyecto);
        listViewProyectos = findViewById(R.id.listViewProyectos);

        // Inicialización de la lista de proyectos (ejemplo)
        listaProyectos.add(new Proyecto("PRJ1", "Proyecto Solar"));
        listaProyectos.add(new Proyecto("PRJ2", "Proyecto Eólico"));

        // Cargar los nombres de los proyectos en el ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getProjectNames(listaProyectos));
        listViewProyectos.setAdapter(adapter);

        // Selector de fecha de inicio
        etFechaInicio.setOnClickListener(v -> mostrarDatePicker());

        // Botón para agregar un nuevo proyecto
        btnAgregarProyecto.setOnClickListener(v -> {
            String nombre = etNombreProyecto.getText().toString();
            String descripcion = etDescripcionProyecto.getText().toString();
            String fechaInicio = etFechaInicio.getText().toString();

            if (!nombre.isEmpty() && !descripcion.isEmpty() && !fechaInicio.isEmpty()) {
                listaProyectos.add(new Proyecto("PRJ" + (listaProyectos.size() + 1), nombre));
                adapter.notifyDataSetChanged();
                limpiarCampos();
                Toast.makeText(GestionProyectosActivity.this, "Proyecto agregado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(GestionProyectosActivity.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            }
        });

        // Botón para eliminar un proyecto
        btnEliminarProyecto.setOnClickListener(v -> {
            int pos = listViewProyectos.getCheckedItemPosition();
            if (pos != ListView.INVALID_POSITION) {
                listaProyectos.remove(pos);
                adapter.notifyDataSetChanged();
                Toast.makeText(GestionProyectosActivity.this, "Proyecto eliminado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(GestionProyectosActivity.this, "Seleccione un proyecto", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Método para obtener los nombres de los proyectos
    private ArrayList<String> getProjectNames(ArrayList<Proyecto> proyectos) {
        ArrayList<String> nombres = new ArrayList<>();
        for (Proyecto proyecto : proyectos) {
            nombres.add(proyecto.getNombre());
        }
        return nombres;
    }

    // Método para mostrar el selector de fecha
    private void mostrarDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int anio = calendar.get(Calendar.YEAR);
        int mes = calendar.get(Calendar.MONTH);
        int dia = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, monthOfYear, dayOfMonth) -> {
            String fechaSeleccionada = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
            etFechaInicio.setText(fechaSeleccionada);
        }, anio, mes, dia);
        datePickerDialog.show();
    }

    // Método para limpiar los campos de entrada
    private void limpiarCampos() {
        etNombreProyecto.setText("");
        etDescripcionProyecto.setText("");
        etFechaInicio.setText("");
    }
}
