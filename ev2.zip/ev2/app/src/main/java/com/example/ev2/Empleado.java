package com.example.ev2;

public class Empleado {
    private String id;
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private String fechaInicio;
    private double salario;
    private String departamentoId;

    public Empleado(String id, String nombre, String direccion, String telefono, String email, String fechaInicio, double salario) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.fechaInicio = fechaInicio;
        this.salario = salario;
        this.departamentoId = null; // No asignado a ningún departamento al principio
    }

    // Getters y setters
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public void setDepartamentoId(String departamentoId) { this.departamentoId = departamentoId; }
    public String getDepartamentoId() { return departamentoId; }
}
