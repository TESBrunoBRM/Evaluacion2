package com.example.ev2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button btnRegistroEmpleado, btnGestionDepartamentos, btnAsignacionEmpleadoDept, btnRegistroTiempo, btnGestionProyectos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRegistroEmpleado = findViewById(R.id.btnRegistroEmpleado);
        btnGestionDepartamentos = findViewById(R.id.btnGestionDepartamentos);
        btnAsignacionEmpleadoDept = findViewById(R.id.btnAsignacionEmpleadoDept);
        btnRegistroTiempo = findViewById(R.id.btnRegistroTiempo);
        btnGestionProyectos = findViewById(R.id.btnGestionProyectos);

        // Registro de empleados
        btnRegistroEmpleado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegistroEmpleadoActivity.class);
                startActivity(intent);
            }
        });

        // Gestión de departamentos
        btnGestionDepartamentos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GestionDepartamentosActivity.class);
                startActivity(intent);
            }
        });

        // Asignación de empleados a departamentos
        btnAsignacionEmpleadoDept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AsignacionEmpleadoDeptActivity.class);
                startActivity(intent);
            }
        });

        // Registro de tiempo
        btnRegistroTiempo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegistroTiempoActivity.class);
                startActivity(intent);
            }
        });

        // Gestión de proyectos
        btnGestionProyectos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GestionProyectosActivity.class);
                startActivity(intent);
            }
        });
    }
}
