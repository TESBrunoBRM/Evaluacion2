package com.example.ev2;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class GestionDepartamentosActivity extends AppCompatActivity {

    ArrayList<Departamento> listaDepartamentos = new ArrayList<>();
    ArrayAdapter<String> adapter;
    ListView listViewDepartamentos;
    EditText etNombreDepartamento, etGerenteDepartamento;
    Button btnAgregarDepartamento, btnEliminarDepartamento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_departamentos);

        // Inicializar los elementos de la vista
        listViewDepartamentos = findViewById(R.id.listViewDepartamentos);
        etNombreDepartamento = findViewById(R.id.etNombreDepartamento);
        etGerenteDepartamento = findViewById(R.id.etGerenteDepartamento);
        btnAgregarDepartamento = findViewById(R.id.btnAgregarDepartamento);
        btnEliminarDepartamento = findViewById(R.id.btnEliminarDepartamento);

        // Simulación de departamentos iniciales
        listaDepartamentos.add(new Departamento("DEP1", "Desarrollo Sostenible", "EMP1"));
        listaDepartamentos.add(new Departamento("DEP2", "Recursos Humanos", "EMP2"));

        // Cargar los nombres de los departamentos en la ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getDepartmentNames(listaDepartamentos));
        listViewDepartamentos.setAdapter(adapter);

        // Botón para agregar un nuevo departamento
        btnAgregarDepartamento.setOnClickListener(v -> {
            String nombre = etNombreDepartamento.getText().toString();
            String gerente = etGerenteDepartamento.getText().toString();

            if (!nombre.isEmpty() && !gerente.isEmpty()) {
                listaDepartamentos.add(new Departamento("DEP" + (listaDepartamentos.size() + 1), nombre, gerente));
                adapter.notifyDataSetChanged();
                etNombreDepartamento.setText("");
                etGerenteDepartamento.setText("");
                Toast.makeText(GestionDepartamentosActivity.this, "Departamento agregado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(GestionDepartamentosActivity.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            }
        });

        // Botón para eliminar el departamento seleccionado
        btnEliminarDepartamento.setOnClickListener(v -> {
            if (!listaDepartamentos.isEmpty()) {
                int pos = listViewDepartamentos.getCheckedItemPosition();
                if (pos != ListView.INVALID_POSITION) {
                    listaDepartamentos.remove(pos);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(GestionDepartamentosActivity.this, "Departamento eliminado", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(GestionDepartamentosActivity.this, "Seleccione un departamento", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Método para obtener los nombres de los departamentos
    private ArrayList<String> getDepartmentNames(ArrayList<Departamento> departamentos) {
        ArrayList<String> nombres = new ArrayList<>();
        for (Departamento dept : departamentos) {
            nombres.add(dept.getNombre());
        }
        return nombres;
    }
}

